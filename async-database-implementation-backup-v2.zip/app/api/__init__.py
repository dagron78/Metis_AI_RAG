from app.api.chat import router as chat_router
from app.api.documents import router as documents_router
from app.api.system import router as system_router