"""
Chunkers module for RAG system
"""