# Query Test Report: multi_entity

## Query Information
- **Original Query**: Compare the properties of Stabilium and Quantum Resonance Modulation in cold fusion experiments.
- **Refined Query**: 
- **Execution Time**: 31.57 seconds

## Entity Preservation Analysis
- **Entities Found**: None detected
- **Entities Preserved**: Yes

## Retrieval Statistics
- **Chunks Retrieved**: 15
- **Chunks Used in Context**: 4

## Sources Used

### Source 1
- **Document**: 
- **Relevance Score**: 0.95
- **Excerpt**: istribution, preventing hotspots
- **Reproducibility**: Significantly improves the reproducibility o...

### Source 2
- **Document**: 
- **Relevance Score**: 0.85
- **Excerpt**: # Quantum Resonance Modulation: Principles and Applications

## Fundamental Principles

Quantum Reso...

### Source 3
- **Document**: 
- **Relevance Score**: 0.80
- **Excerpt**: te
2. QRM systems create the conditions for quantum tunneling
3. The combined approach increases fus...

### Source 4
- **Document**: 
- **Relevance Score**: 0.75
- **Excerpt**: # Stabilium Versions: Comparative Analysis

## Evolution of Stabilium Technology

Since its initial ...

## Generated Answer
```
I've searched for information on this topic. While my knowledge is limited, However, the combined approach of QRM systems and Stabilium increases fusion efficiency by approximately 300% compared to traditional methods [3].
```
